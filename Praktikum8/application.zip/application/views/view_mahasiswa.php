<?php
foreach($Mahasiswa as $row)
{
    echo "Nama : ".$row['nama'];
    echo "<br/>";
    echo "Prodi : ".$row['prodi'];
    echo "<hr/>";
}?>